angular.module('starter.controllers', [])

.controller('LoginCtrl', function($state, $scope, Chats) {
    $scope.login = function(user) {

        $state.go("tab.organization");

        // Parse.User.logIn(user.username, user.password, {
        //     success: function(user) {
        //         console.log(user.id);

        //         $state.go("tab.orders");
        //     },
        //     error: function(user, error) {
        //         alert("login failed:" + error);
        //         console.log("failed");


        //     }
        // });
    }

    $scope.register = function(argument) {
        $state.go("login.setup")
    }

    $scope.changePassword = function(argument) {
        $state.go("login.password")
    }

    $scope.survivorAccess = function(argument) {
        $state.go("tab.map");
    }

})

.controller('OrganizationCtrl', function($state, $scope) {

    $scope.neworg = function(argument) {
        $state.go("tab.neworg");
    }

    $scope.requestFood = function(argument) {
        $state.go("tab.reqfood");
    }

    $scope.editorg = function(argument) {
        $state.go("tab.editorg");
    }

    $scope.map = function(argument) {
        $state.go("tab.map");
    }


})

.controller('EditOrgCtrl', function($state, $scope) {
    var self = this;

    var img = "";

    var Org = Parse.Object.extend("Organization");
    var query = new Parse.Query(Org);
    //query.equalTo("id", $stateParams.id);
    query.find().then(function(objs) {
        console.log("Searching");

        $scope.orgs = [];
        for (var i = objs.length - 1; i >= 0; i--) {

            // if (objs[i].get("category") == "Food") {
            //     img = "img/food.jpg";
            // }
            // if (objs[i].get("category") == "Stationary") {
            //     img = "img/clothing.jpg";
            // }
            // if (objs[i].get("category") == "Clothing") {
            //     img = "img/stationary.jpg";
            // }

            $scope.orgs.push({
                name: objs[i].get("name"),
                phone: objs[i].get("phone"),
                //img: img,
                address: objs[i].get("address"),
                city: objs[i].get("city"),
                zipcode: objs[i].get("zipcode"),
                state: objs[i].get("state"),
                email: objs[i].get("email"),
                search: objs[i].get("name"),
                id: objs[i].id //???                
            });

        }
        $scope.apply();
    });


    $scope.remove = function(order) {
        id = order.id;

        var Order = Parse.Object.extend("Order");
        var o = new Order();
        o.id = id;
        o.destroy({
            success: function(myObject) {
                console.log("deleted");
                index = $scope.orders.indexOf(order);
                $scope.orders.splice(index, 1);
                $scope.$apply();
            },
            error: function(myObject, error) {

            }
        })
    }

    $scope.request = function(argument) {
        $state.go("tab.reqfood");
    }

    $scope.cancel = function(argument) {
        $state.go("tab.organization");
    }

})

.controller('MapCtrl', function($state, $scope, $cordovaGeolocation) {

    // var options = { timeout: 1000, enableHighAccuracy: false };

    // $cordovaGeolocation.getCurrentPosition(options).then(function(position) {

    //     var latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
    //     console.log("3");

    //     var mapOptions = {
    //         center: latLng,
    //         zoom: 15,
    //         mapTypeId: google.maps.MapTypeId.ROADMAP
    //     };

    //     $scope.map = new google.maps.Map(document.getElementById("map"), mapOptions);

    // }, function(error) {
    //     console.log("Could not get location");
    // });

    $scope.mapCreated = function(map) {
        $scope.map = map;
    };

    $scope.centerOnMe = function() {
        console.log("Centering");
        if (!$scope.map) {
            return;
        }

        $scope.loading = $ionicLoading.show({
            content: 'Getting current location...',
            showBackdrop: false
        });

        navigator.geolocation.getCurrentPosition(function(pos) {
            console.log('Got pos', pos);
            $scope.map.setCenter(new google.maps.LatLng(pos.coords.latitude, pos.coords.longitude));
            $scope.loading.hide();
        }, function(error) {
            alert('Unable to get location: ' + error.message);
        });
    };

})

.controller('SetupCtrl', function($scope, $state, Chats) {

    $scope.register = function(user) {
        console.log(user.email);
        console.log(user.password);

        var u = new Parse.User();
        u.set("email", user.email);
        u.set("password", user.password);
        u.set("username", user.email);

        u.signUp(null, {
            success: function(u) {
                console.log(u.id);
            },
            error: function(user, error) {
                console.log("Error: " + error.code + " " + error.message);
                return;
            }
        });

        $state.go("login.login");
    }

    $scope.cancel = function(argument) {
        console.log("cancel");
        $state.go("login.login");
    }

})

.controller('NewOrderCtrl', function($scope, $ionicHistory, $state, Chats) {

    $scope.neworder = function(order) {
        if (order) {

            var Order = Parse.Object.extend("Order");
            var o = new Order();
            o.set("name", order.name);
            o.set("quantity", order.qty);
            o.set("date", order.date);
            o.set("price", order.price);
            o.set("category", order.category);

            o.save(null, {
                success: function(o) {

                    $scope.apply();
                },
                error: function(o, error) {
                    alert('Failed to create new object, with error code: ' + error.message);
                }
            });

            $state.go("tab.orders");
        }
    };
    $scope.cancel = function(argument) {
        $state.go("tab.orders");
    };
})

.controller('ReqFoodCtrl', function($scope, $ionicHistory, $state) {
    $scope.cancel = function(argument) {
        $state.go("tab.organization");
    };
    $scope.reqfood = function(req) {
        console.log($scope.id);

        if (req) {

            var Req = Parse.Object.extend("Organization");
            var o = new Org();
            o.set("name", order.name);
            o.set("address", order.address);
            o.set("phone", order.phone);
            o.set("email", order.email);

            o.save(null, {
                success: function(o) {

                    $scope.apply();
                },
                error: function(o, error) {
                    alert('Failed to create new object, with error code: ' + error.message);
                }
            });

            $state.go("tab.orders");
        }
    };

})

.controller('NewOrgCtrl', function($scope, $ionicHistory, $state) {
    $scope.cancel = function(argument) {
        $state.go("tab.organization");
    };
    $scope.neworg = function(org) {
        if (org) {

            var Org = Parse.Object.extend("Organization");
            var o = new Org();
            o.set("name", org.name);
            o.set("address", org.address);
            o.set("city", org.city);
            o.set("zipcode", org.zipcode);
            o.set("state", org.state);
            o.set("phone", org.phone);
            o.set("email", org.email);

            o.save(null, {
                success: function(o) {
                    console.log(org.state);
                    console.log("ok");
                    $scope.apply();

                },
                error: function(o, error) {
                    alert('Failed to create new object, with error code: ' + error.message);
                }
            });

            $state.go("tab.orders");
        }
    };
})

.controller('OrderCtrl', function($scope, $state) {

    var self = this;

    var img = "";

    var Order = Parse.Object.extend("Order");
    var query = new Parse.Query(Order);

    query.find().then(function(objs) {
        console.log("Searching");

        $scope.orders = [];
        for (var i = objs.length - 1; i >= 0; i--) {

            if (objs[i].get("category") == "Food") {
                img = "img/food.jpg";
            }
            if (objs[i].get("category") == "Stationary") {
                img = "img/clothing.jpg";
            }
            if (objs[i].get("category") == "Clothing") {
                img = "img/stationary.jpg";
            }

            $scope.orders.push({
                qty: objs[i].get("quantity"),
                name: objs[i].get("name"),
                img: img,
                price: objs[i].get("price"),
                date: objs[i].get("date"),
                category: objs[i].get("category"),
                search: objs[i].get("name"),
                id: objs[i].id //???                
            });

        }
        $scope.apply();
    });


    $scope.remove = function(order) {
        id = order.id;

        var Order = Parse.Object.extend("Order");
        var o = new Order();
        o.id = id;
        o.destroy({
            success: function(myObject) {
                console.log("deleted");
                index = $scope.orders.indexOf(order);
                $scope.orders.splice(index, 1);
                $scope.$apply();
            },
            error: function(myObject, error) {

            }
        })
    }

    $scope.neworder = function(argument) {
        $state.go("tab.neworder");
    }
})

.controller('OrgDetailCtrl', function($scope, $stateParams, $state) {

        var orgId;

        var Org = Parse.Object.extend("Organization");
        var query = new Parse.Query(Org);
        query.equalTo("id", $stateParams.id);
        query.find().then(function(objs) {
            for (var i = objs.length - 1; i >= 0; i--) {
                if (objs[i].id === $stateParams.Id) {
                    $scope.name = objs[i].get("name");
                    $scope.id = objs[i].id;
                    orgId = objs[i].id;
                    console.log(orgId);
                    // $scope.orderId = objs[i].get("orderId");
                    // $scope.qty = objs[i].get("quantity");
                    // $scope.price = objs[i].get("price");
                    // $scope.date = objs[i].get("date");
                    // $scope.category = objs[i].get("category");
                }

            }
        });

        var Inventory = Parse.Object.extend("Inventory");
        var queryInv = new Parse.Query(Inventory);
        console.log(orgId);
        queryInv.equalTo("id", $scope.id);
        queryInv.find().then(function(objsInv) {

            $scope.itens = [];
            for (var i = objsInv.length - 1; i >= 0; i--) {

                $scope.itens.push({
                    qty: objsInv[i].get("quantity"),
                    category: objsInv[i].get("category"),
                    date: objsInv[i].get("date"),
                    idOrg: objsInv[i].get("idOrg"),
                    id: objsInv[i].id //???                
                });


            }
            $scope.apply();
        });

        $scope.request = function(id) {
            console.log($scope.id);
            $state.go("tab.reqfood");
        }

    })
    .controller('OrderDetailCtrl', function($scope, $stateParams, $state) {

        var Order = Parse.Object.extend("Order");
        var query = new Parse.Query(Order);
        query.equalTo("id", $stateParams.id);
        query.find().then(function(objs) {
            for (var i = objs.length - 1; i >= 0; i--) {
                if (objs[i].id === $stateParams.Id) {
                    $scope.name = objs[i].get("name");
                    $scope.orderId = objs[i].get("orderId");
                    $scope.qty = objs[i].get("quantity");
                    $scope.price = objs[i].get("price");
                    $scope.date = objs[i].get("date");
                    $scope.category = objs[i].get("category");
                }

            }
        });

    });
