import java.lang.Math;

public class RussianMultiply {

public static int multiply(int a, int b){

	
	return 0;
}
	
}
