

import java.util.*;
import java.lang.Math;

public class SwitchGenerator {


	
	public SwitchGenerator(int n_switches){

	}
	
	//returns the 0-based index of the next switch to flip/toggle
	public int next(){

		return 0;
		
	}
	

}
