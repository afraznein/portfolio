
public class Lomuto {

	public static int partition(int[] A, int low, int high){

		return 0;
	}
	
}
