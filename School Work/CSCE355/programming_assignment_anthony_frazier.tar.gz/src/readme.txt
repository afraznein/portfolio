Name: Anthony Frazier
Class: CSCE355
Date: November 21, 2017
Programming Assignment

I have currently implemented simulator.txt and boolop.txt. I have both of those working 100%. I have spent a lot of time on minimization and properties(minimization.txt and properties.txt), but neither of these tasks are fully complete.

I have 3 execution errors with minimization and 1 execution error with properties.


